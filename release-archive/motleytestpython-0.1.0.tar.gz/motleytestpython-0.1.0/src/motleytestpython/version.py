"""Specifies the motleytestpython package distribution version."""
__version__ = '0.1.0'
if __name__=='__main__':
    print(__version__)
