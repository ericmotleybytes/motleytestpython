# motleytestpython
Simple and quick sanity check that Python is working correctly.
